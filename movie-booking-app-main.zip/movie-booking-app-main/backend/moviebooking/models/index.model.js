module.exports = {
  Movie: require("./movie.model"),
  Genre: require("./genre.model"),
  Artist: require("./artist.model"),
  User: require("./user.model"),
};
